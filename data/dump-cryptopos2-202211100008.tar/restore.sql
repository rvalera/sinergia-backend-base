--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.20 (Debian 10.20-1.pgdg90+1)
-- Dumped by pg_dump version 12.12 (Ubuntu 12.12-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cryptopos2;
--
-- Name: cryptopos2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cryptopos2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE cryptopos2 OWNER TO postgres;

\connect cryptopos2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hospitalario; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA hospitalario;


ALTER SCHEMA hospitalario OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: cita_id_seq; Type: SEQUENCE; Schema: hospitalario; Owner: postgres
--

CREATE SEQUENCE hospitalario.cita_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitalario.cita_id_seq OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: empresa; Type: TABLE; Schema: hospitalario; Owner: postgres
--

CREATE TABLE hospitalario.empresa (
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.empresa OWNER TO postgres;

--
-- Name: application; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application (
    id integer NOT NULL,
    name character varying(50),
    app_key character varying(64),
    app_iv character varying(64),
    status character varying(1),
    default_fiat_coin_id integer,
    default_crypto_coin_id integer
);


ALTER TABLE public.application OWNER TO postgres;

--
-- Name: application_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.application_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_id_seq OWNER TO postgres;

--
-- Name: application_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.application_id_seq OWNED BY public.application.id;


--
-- Name: bank; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank (
    id integer NOT NULL,
    name character varying(150),
    status character varying(1)
);


ALTER TABLE public.bank OWNER TO postgres;

--
-- Name: bank_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bank_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bank_id_seq OWNER TO postgres;

--
-- Name: bank_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bank_id_seq OWNED BY public.bank.id;


--
-- Name: coin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coin (
    id integer NOT NULL,
    name character varying(50),
    description character varying(128),
    creation_date timestamp without time zone,
    diminutive character varying(5),
    th_separator character varying(1),
    dec_separator character varying(1),
    status character varying(1),
    blockchain_address character varying(128),
    application_id integer
);


ALTER TABLE public.coin OWNER TO postgres;

--
-- Name: coin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.coin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.coin_id_seq OWNER TO postgres;

--
-- Name: coin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.coin_id_seq OWNED BY public.coin.id;


--
-- Name: function; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.function (
    id integer NOT NULL,
    name character varying(50),
    long_name character varying(100),
    link character varying(50),
    icon character varying(50),
    is_container boolean,
    parent_id integer,
    "order" integer,
    status character varying(1)
);


ALTER TABLE public.function OWNER TO postgres;

--
-- Name: function_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.function_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.function_id_seq OWNER TO postgres;

--
-- Name: function_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.function_id_seq OWNED BY public.function.id;


--
-- Name: function_rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.function_rol (
    rol_id integer,
    function_id integer
);


ALTER TABLE public.function_rol OWNER TO postgres;

--
-- Name: personextension; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personextension (
    id integer NOT NULL,
    type character varying(1),
    id_number character varying(25),
    first_name character varying(100),
    last_name character varying(100),
    fullname character varying(100),
    birth_date timestamp without time zone,
    gender character varying(1),
    address character varying(250),
    phone_number character varying(25),
    email character varying(128),
    secondary_email character varying(128),
    bank_id integer,
    account_number character varying(50),
    status character varying(1),
    cedula character varying(12),
    empresa_id character varying(10)
);


ALTER TABLE public.personextension OWNER TO postgres;

--
-- Name: personextension_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personextension_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personextension_id_seq OWNER TO postgres;

--
-- Name: personextension_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personextension_id_seq OWNED BY public.personextension.id;


--
-- Name: privilege; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.privilege (
    id integer NOT NULL,
    short_name character varying(5),
    name character varying(32)
);


ALTER TABLE public.privilege OWNER TO postgres;

--
-- Name: privilege_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.privilege_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.privilege_id_seq OWNER TO postgres;

--
-- Name: privilege_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.privilege_id_seq OWNED BY public.privilege.id;


--
-- Name: rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rol (
    id integer NOT NULL,
    name character varying(32)
);


ALTER TABLE public.rol OWNER TO postgres;

--
-- Name: rol_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rol_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rol_id_seq OWNER TO postgres;

--
-- Name: rol_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rol_id_seq OWNED BY public.rol.id;


--
-- Name: rol_privilege; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rol_privilege (
    rol_id integer,
    privilege_id integer
);


ALTER TABLE public.rol_privilege OWNER TO postgres;

--
-- Name: securityelement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.securityelement (
    id integer NOT NULL,
    name character varying(128),
    password_hash character varying(128),
    status character varying(1),
    discriminator character varying
);


ALTER TABLE public.securityelement OWNER TO postgres;

--
-- Name: securityelement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.securityelement_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.securityelement_id_seq OWNER TO postgres;

--
-- Name: securityelement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.securityelement_id_seq OWNED BY public.securityelement.id;


--
-- Name: securityelement_rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.securityelement_rol (
    securityelement_id integer,
    rol_id integer
);


ALTER TABLE public.securityelement_rol OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    person_extension_id integer,
    operation_key character varying(128),
    register_mode character varying(1),
    register_date timestamp without time zone,
    type character varying(1)
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: application id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application ALTER COLUMN id SET DEFAULT nextval('public.application_id_seq'::regclass);


--
-- Name: bank id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank ALTER COLUMN id SET DEFAULT nextval('public.bank_id_seq'::regclass);


--
-- Name: coin id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coin ALTER COLUMN id SET DEFAULT nextval('public.coin_id_seq'::regclass);


--
-- Name: function id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function ALTER COLUMN id SET DEFAULT nextval('public.function_id_seq'::regclass);


--
-- Name: personextension id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personextension ALTER COLUMN id SET DEFAULT nextval('public.personextension_id_seq'::regclass);


--
-- Name: privilege id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privilege ALTER COLUMN id SET DEFAULT nextval('public.privilege_id_seq'::regclass);


--
-- Name: rol id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol ALTER COLUMN id SET DEFAULT nextval('public.rol_id_seq'::regclass);


--
-- Name: securityelement id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.securityelement ALTER COLUMN id SET DEFAULT nextval('public.securityelement_id_seq'::regclass);


--
-- Data for Name: empresa; Type: TABLE DATA; Schema: hospitalario; Owner: postgres
--

COPY hospitalario.empresa (codigo, nombre) FROM stdin;
\.
COPY hospitalario.empresa (codigo, nombre) FROM '$$PATH$$/2958.dat';

--
-- Data for Name: application; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application (id, name, app_key, app_iv, status, default_fiat_coin_id, default_crypto_coin_id) FROM stdin;
\.
COPY public.application (id, name, app_key, app_iv, status, default_fiat_coin_id, default_crypto_coin_id) FROM '$$PATH$$/2976.dat';

--
-- Data for Name: bank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank (id, name, status) FROM stdin;
\.
COPY public.bank (id, name, status) FROM '$$PATH$$/2959.dat';

--
-- Data for Name: coin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coin (id, name, description, creation_date, diminutive, th_separator, dec_separator, status, blockchain_address, application_id) FROM stdin;
\.
COPY public.coin (id, name, description, creation_date, diminutive, th_separator, dec_separator, status, blockchain_address, application_id) FROM '$$PATH$$/2978.dat';

--
-- Data for Name: function; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.function (id, name, long_name, link, icon, is_container, parent_id, "order", status) FROM stdin;
\.
COPY public.function (id, name, long_name, link, icon, is_container, parent_id, "order", status) FROM '$$PATH$$/2961.dat';

--
-- Data for Name: function_rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.function_rol (rol_id, function_id) FROM stdin;
\.
COPY public.function_rol (rol_id, function_id) FROM '$$PATH$$/2963.dat';

--
-- Data for Name: personextension; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personextension (id, type, id_number, first_name, last_name, fullname, birth_date, gender, address, phone_number, email, secondary_email, bank_id, account_number, status, cedula, empresa_id) FROM stdin;
\.
COPY public.personextension (id, type, id_number, first_name, last_name, fullname, birth_date, gender, address, phone_number, email, secondary_email, bank_id, account_number, status, cedula, empresa_id) FROM '$$PATH$$/2964.dat';

--
-- Data for Name: privilege; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.privilege (id, short_name, name) FROM stdin;
\.
COPY public.privilege (id, short_name, name) FROM '$$PATH$$/2966.dat';

--
-- Data for Name: rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rol (id, name) FROM stdin;
\.
COPY public.rol (id, name) FROM '$$PATH$$/2968.dat';

--
-- Data for Name: rol_privilege; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rol_privilege (rol_id, privilege_id) FROM stdin;
\.
COPY public.rol_privilege (rol_id, privilege_id) FROM '$$PATH$$/2970.dat';

--
-- Data for Name: securityelement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.securityelement (id, name, password_hash, status, discriminator) FROM stdin;
\.
COPY public.securityelement (id, name, password_hash, status, discriminator) FROM '$$PATH$$/2971.dat';

--
-- Data for Name: securityelement_rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.securityelement_rol (securityelement_id, rol_id) FROM stdin;
\.
COPY public.securityelement_rol (securityelement_id, rol_id) FROM '$$PATH$$/2973.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, person_extension_id, operation_key, register_mode, register_date, type) FROM stdin;
\.
COPY public."user" (id, person_extension_id, operation_key, register_mode, register_date, type) FROM '$$PATH$$/2974.dat';

--
-- Name: cita_id_seq; Type: SEQUENCE SET; Schema: hospitalario; Owner: postgres
--

SELECT pg_catalog.setval('hospitalario.cita_id_seq', 350, true);


--
-- Name: application_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.application_id_seq', 1, true);


--
-- Name: bank_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_id_seq', 500, true);


--
-- Name: coin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coin_id_seq', 3, true);


--
-- Name: function_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.function_id_seq', 500, true);


--
-- Name: personextension_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personextension_id_seq', 576, true);


--
-- Name: privilege_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.privilege_id_seq', 500, true);


--
-- Name: rol_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rol_id_seq', 501, true);


--
-- Name: securityelement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.securityelement_id_seq', 577, true);


--
-- Name: empresa pk_empresa; Type: CONSTRAINT; Schema: hospitalario; Owner: postgres
--

ALTER TABLE ONLY hospitalario.empresa
    ADD CONSTRAINT pk_empresa PRIMARY KEY (codigo);


--
-- Name: application application_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application
    ADD CONSTRAINT application_pkey PRIMARY KEY (id);


--
-- Name: bank bank_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank
    ADD CONSTRAINT bank_pkey PRIMARY KEY (id);


--
-- Name: coin coin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coin
    ADD CONSTRAINT coin_pkey PRIMARY KEY (id);


--
-- Name: function function_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_pkey PRIMARY KEY (id);


--
-- Name: personextension personextension_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personextension
    ADD CONSTRAINT personextension_pkey PRIMARY KEY (id);


--
-- Name: privilege privilege_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privilege
    ADD CONSTRAINT privilege_pkey PRIMARY KEY (id);


--
-- Name: privilege privilege_short_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privilege
    ADD CONSTRAINT privilege_short_name_key UNIQUE (short_name);


--
-- Name: rol rol_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT rol_pkey PRIMARY KEY (id);


--
-- Name: securityelement securityelement_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.securityelement
    ADD CONSTRAINT securityelement_name_key UNIQUE (name);


--
-- Name: securityelement securityelement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.securityelement
    ADD CONSTRAINT securityelement_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: coin coin_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coin
    ADD CONSTRAINT coin_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.application(id);


--
-- Name: function function_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.function(id);


--
-- Name: function_rol function_rol_function_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function_rol
    ADD CONSTRAINT function_rol_function_id_fkey FOREIGN KEY (function_id) REFERENCES public.function(id);


--
-- Name: function_rol function_rol_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function_rol
    ADD CONSTRAINT function_rol_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.rol(id);


--
-- Name: personextension personextension_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personextension
    ADD CONSTRAINT personextension_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.bank(id);


--
-- Name: personextension personextension_empresa_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personextension
    ADD CONSTRAINT personextension_empresa_fk FOREIGN KEY (empresa_id) REFERENCES hospitalario.empresa(codigo);


--
-- Name: rol_privilege rol_privilege_privilege_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol_privilege
    ADD CONSTRAINT rol_privilege_privilege_id_fkey FOREIGN KEY (privilege_id) REFERENCES public.privilege(id);


--
-- Name: rol_privilege rol_privilege_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol_privilege
    ADD CONSTRAINT rol_privilege_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.rol(id);


--
-- Name: securityelement_rol securityelement_rol_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.securityelement_rol
    ADD CONSTRAINT securityelement_rol_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.rol(id);


--
-- Name: securityelement_rol securityelement_rol_securityelement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.securityelement_rol
    ADD CONSTRAINT securityelement_rol_securityelement_id_fkey FOREIGN KEY (securityelement_id) REFERENCES public.securityelement(id);


--
-- Name: user user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_id_fkey FOREIGN KEY (id) REFERENCES public.securityelement(id);


--
-- Name: user user_person_extension_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_person_extension_id_fkey FOREIGN KEY (person_extension_id) REFERENCES public.personextension(id);


--
-- PostgreSQL database dump complete
--

