--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.20
-- Dumped by pg_dump version 12.9 (Ubuntu 12.9-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hospitalariocvg;
--
-- Name: hospitalariocvg; Type: DATABASE; Schema: -; Owner: doadmin
--

CREATE DATABASE hospitalariocvg WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE hospitalariocvg OWNER TO doadmin;

\connect hospitalariocvg

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hospitalario; Type: SCHEMA; Schema: -; Owner: doadmin
--

CREATE SCHEMA hospitalario;


ALTER SCHEMA hospitalario OWNER TO doadmin;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

--
-- Name: area; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.area (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.area OWNER TO doadmin;

--
-- Name: area_id_seq; Type: SEQUENCE; Schema: hospitalario; Owner: doadmin
--

CREATE SEQUENCE hospitalario.area_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitalario.area_id_seq OWNER TO doadmin;

--
-- Name: area_id_seq; Type: SEQUENCE OWNED BY; Schema: hospitalario; Owner: doadmin
--

ALTER SEQUENCE hospitalario.area_id_seq OWNED BY hospitalario.area.id;


--
-- Name: beneficiario; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.beneficiario (
    cedula character varying(12) NOT NULL,
    vinculo character varying(100)
);


ALTER TABLE hospitalario.beneficiario OWNER TO doadmin;

--
-- Name: cita; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.cita (
    id integer NOT NULL,
    cedula character varying(12) NOT NULL,
    codigoespecialidad character varying(12),
    fechadia timestamp without time zone NOT NULL,
    fechacita timestamp without time zone,
    fechaentradacola timestamp without time zone,
    fechapasaconsulta timestamp without time zone,
    fechafinconsulta timestamp without time zone,
    idbiostar character varying(100)
);


ALTER TABLE hospitalario.cita OWNER TO doadmin;

--
-- Name: cita_id_seq; Type: SEQUENCE; Schema: hospitalario; Owner: doadmin
--

CREATE SEQUENCE hospitalario.cita_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitalario.cita_id_seq OWNER TO doadmin;

--
-- Name: cita_id_seq; Type: SEQUENCE OWNED BY; Schema: hospitalario; Owner: doadmin
--

ALTER SEQUENCE hospitalario.cita_id_seq OWNED BY hospitalario.cita.id;


--
-- Name: consultamedica; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.consultamedica (
    id integer NOT NULL,
    cedula character varying(12) NOT NULL,
    cedulamedico character varying(12) NOT NULL,
    sintomas text NOT NULL,
    diagnostico text NOT NULL,
    tratamiento text NOT NULL,
    examenes text,
    fecha date NOT NULL,
    idcita integer
);


ALTER TABLE hospitalario.consultamedica OWNER TO doadmin;

--
-- Name: consultamedica_id_seq; Type: SEQUENCE; Schema: hospitalario; Owner: doadmin
--

CREATE SEQUENCE hospitalario.consultamedica_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitalario.consultamedica_id_seq OWNER TO doadmin;

--
-- Name: consultamedica_id_seq; Type: SEQUENCE OWNED BY; Schema: hospitalario; Owner: doadmin
--

ALTER SEQUENCE hospitalario.consultamedica_id_seq OWNED BY hospitalario.consultamedica.id;


--
-- Name: consultorio; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.consultorio (
    idconsultorio integer NOT NULL,
    idsala integer,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.consultorio OWNER TO doadmin;

--
-- Name: consultorio_idconsultorio_seq; Type: SEQUENCE; Schema: hospitalario; Owner: doadmin
--

CREATE SEQUENCE hospitalario.consultorio_idconsultorio_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitalario.consultorio_idconsultorio_seq OWNER TO doadmin;

--
-- Name: consultorio_idconsultorio_seq; Type: SEQUENCE OWNED BY; Schema: hospitalario; Owner: doadmin
--

ALTER SEQUENCE hospitalario.consultorio_idconsultorio_seq OWNED BY hospitalario.consultorio.idconsultorio;


--
-- Name: empresa; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.empresa (
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.empresa OWNER TO doadmin;

--
-- Name: especialidad; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.especialidad (
    codigoespecialidad character varying(12) NOT NULL,
    nombre character varying(100) NOT NULL,
    autogestionada boolean NOT NULL,
    diasdeatencion character varying(100),
    cantidadmaximapacientes integer NOT NULL
);


ALTER TABLE hospitalario.especialidad OWNER TO doadmin;

--
-- Name: especialidadsalaspera; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.especialidadsalaspera (
    codi_espe character varying(12) NOT NULL,
    idsala integer NOT NULL
);


ALTER TABLE hospitalario.especialidadsalaspera OWNER TO doadmin;

--
-- Name: estado; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.estado (
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.estado OWNER TO doadmin;

--
-- Name: estatustrabajador; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.estatustrabajador (
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.estatustrabajador OWNER TO doadmin;

--
-- Name: historiamedica; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.historiamedica (
    cedula character varying(12) NOT NULL,
    gruposanguineo character varying(12) NOT NULL,
    discapacidad character varying(10),
    fecha date NOT NULL
);


ALTER TABLE hospitalario.historiamedica OWNER TO doadmin;

--
-- Name: medico; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.medico (
    cedulamedico character varying(12) NOT NULL,
    codigoespecialidad character varying(12) NOT NULL,
    codigoconsultorio integer
);


ALTER TABLE hospitalario.medico OWNER TO doadmin;

--
-- Name: municipio; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.municipio (
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL,
    codigopadre character varying(10)
);


ALTER TABLE hospitalario.municipio OWNER TO doadmin;

--
-- Name: parroquia; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.parroquia (
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL,
    codigopadre character varying(10)
);


ALTER TABLE hospitalario.parroquia OWNER TO doadmin;

--
-- Name: patologia; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.patologia (
    codigopatologia character varying(12) NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.patologia OWNER TO doadmin;

--
-- Name: patologiahistoriamedica; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.patologiahistoriamedica (
    cedula character varying(12) NOT NULL,
    codigopatologia character varying(12) NOT NULL
);


ALTER TABLE hospitalario.patologiahistoriamedica OWNER TO doadmin;

--
-- Name: persona; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.persona (
    cedula character varying(12) NOT NULL,
    nombres character varying(100) NOT NULL,
    apellidos character varying(100) NOT NULL,
    nacionalidad character(1),
    fechanacimiento date,
    sexo character(1),
    nivel character varying(100),
    profesion character varying(100),
    telefonocelular character varying(12),
    telefonoresidencia character varying(12),
    correo character varying(100),
    codigoestado character varying(10),
    codigomunicipio character varying(10),
    parroquia character varying(100),
    sector character varying(100),
    avenidacalle character varying(100),
    edifcasa character varying(100)
);


ALTER TABLE hospitalario.persona OWNER TO doadmin;

--
-- Name: saladeespera; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.saladeespera (
    idsala integer NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.saladeespera OWNER TO doadmin;

--
-- Name: saladeespera_idsala_seq; Type: SEQUENCE; Schema: hospitalario; Owner: doadmin
--

CREATE SEQUENCE hospitalario.saladeespera_idsala_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitalario.saladeespera_idsala_seq OWNER TO doadmin;

--
-- Name: saladeespera_idsala_seq; Type: SEQUENCE OWNED BY; Schema: hospitalario; Owner: doadmin
--

ALTER SEQUENCE hospitalario.saladeespera_idsala_seq OWNED BY hospitalario.saladeespera.idsala;


--
-- Name: tipocargo; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.tipocargo (
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.tipocargo OWNER TO doadmin;

--
-- Name: tiponomina; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.tiponomina (
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.tiponomina OWNER TO doadmin;

--
-- Name: tipotrabajador; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.tipotrabajador (
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.tipotrabajador OWNER TO doadmin;

--
-- Name: trabajador; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.trabajador (
    cedula character varying(12) NOT NULL,
    personal character varying(100),
    tiponomina character varying(100),
    ubicacionlaboral character varying(100),
    cargo character varying(100),
    codigoempresa character varying(10),
    jornada character varying(100),
    ingreso date,
    situacion character varying(100),
    condicion character varying(100),
    camisa character varying(5),
    pantalon character varying(5),
    calzado character varying(5),
    ficha character varying(12),
    observaciones text,
    fechaactualizacion timestamp without time zone,
    idusuarioactualizacion integer,
    suspendido character varying(10)
);


ALTER TABLE hospitalario.trabajador OWNER TO doadmin;

--
-- Name: ubicacionlaboral; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.ubicacionlaboral (
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE hospitalario.ubicacionlaboral OWNER TO doadmin;

--
-- Name: visita; Type: TABLE; Schema: hospitalario; Owner: doadmin
--

CREATE TABLE hospitalario.visita (
    cedula character varying(12) NOT NULL,
    idarea integer,
    nombre character varying(100) NOT NULL,
    apellidos character varying(100) NOT NULL,
    telefonocelular character varying(100),
    telefonofijo character varying(100),
    correo character varying(100),
    responsable character varying(100) NOT NULL,
    id integer NOT NULL
);


ALTER TABLE hospitalario.visita OWNER TO doadmin;

--
-- Name: visita_id_seq; Type: SEQUENCE; Schema: hospitalario; Owner: doadmin
--

CREATE SEQUENCE hospitalario.visita_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hospitalario.visita_id_seq OWNER TO doadmin;

--
-- Name: visita_id_seq; Type: SEQUENCE OWNED BY; Schema: hospitalario; Owner: doadmin
--

ALTER SEQUENCE hospitalario.visita_id_seq OWNED BY hospitalario.visita.id;


--
-- Name: bank; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.bank (
    id integer NOT NULL,
    name character varying(150),
    status character varying(1)
);


ALTER TABLE public.bank OWNER TO doadmin;

--
-- Name: bank_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.bank_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bank_id_seq OWNER TO doadmin;

--
-- Name: bank_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.bank_id_seq OWNED BY public.bank.id;


--
-- Name: function; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.function (
    id integer NOT NULL,
    name character varying(50),
    long_name character varying(100),
    link character varying(50),
    icon character varying(50),
    is_container boolean,
    parent_id integer,
    "order" integer,
    status character varying(1)
);


ALTER TABLE public.function OWNER TO doadmin;

--
-- Name: function_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.function_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.function_id_seq OWNER TO doadmin;

--
-- Name: function_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.function_id_seq OWNED BY public.function.id;


--
-- Name: function_rol; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.function_rol (
    rol_id integer,
    function_id integer
);


ALTER TABLE public.function_rol OWNER TO doadmin;

--
-- Name: personextension; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.personextension (
    id integer NOT NULL,
    type character varying(1),
    id_number character varying(25),
    first_name character varying(100),
    last_name character varying(100),
    fullname character varying(100),
    birth_date timestamp without time zone,
    gender character varying(1),
    address character varying(250),
    phone_number character varying(25),
    email character varying(128),
    secondary_email character varying(128),
    bank_id integer,
    account_number character varying(50),
    status character varying(1),
    cedula character varying(12)
);


ALTER TABLE public.personextension OWNER TO doadmin;

--
-- Name: personextension_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.personextension_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personextension_id_seq OWNER TO doadmin;

--
-- Name: personextension_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.personextension_id_seq OWNED BY public.personextension.id;


--
-- Name: privilege; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.privilege (
    id integer NOT NULL,
    short_name character varying(5),
    name character varying(32)
);


ALTER TABLE public.privilege OWNER TO doadmin;

--
-- Name: privilege_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.privilege_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.privilege_id_seq OWNER TO doadmin;

--
-- Name: privilege_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.privilege_id_seq OWNED BY public.privilege.id;


--
-- Name: rol; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.rol (
    id integer NOT NULL,
    name character varying(32)
);


ALTER TABLE public.rol OWNER TO doadmin;

--
-- Name: rol_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.rol_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rol_id_seq OWNER TO doadmin;

--
-- Name: rol_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.rol_id_seq OWNED BY public.rol.id;


--
-- Name: rol_privilege; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.rol_privilege (
    rol_id integer,
    privilege_id integer
);


ALTER TABLE public.rol_privilege OWNER TO doadmin;

--
-- Name: securityelement; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.securityelement (
    id integer NOT NULL,
    name character varying(128),
    password_hash character varying(128),
    status character varying(1),
    discriminator character varying
);


ALTER TABLE public.securityelement OWNER TO doadmin;

--
-- Name: securityelement_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.securityelement_id_seq
    AS integer
    START WITH 500
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.securityelement_id_seq OWNER TO doadmin;

--
-- Name: securityelement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.securityelement_id_seq OWNED BY public.securityelement.id;


--
-- Name: securityelement_rol; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.securityelement_rol (
    securityelement_id integer,
    rol_id integer
);


ALTER TABLE public.securityelement_rol OWNER TO doadmin;

--
-- Name: user; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    person_extension_id integer,
    operation_key character varying(128),
    register_mode character varying(1),
    register_date timestamp without time zone,
    type character varying(1)
);


ALTER TABLE public."user" OWNER TO doadmin;

--
-- Name: area id; Type: DEFAULT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.area ALTER COLUMN id SET DEFAULT nextval('hospitalario.area_id_seq'::regclass);


--
-- Name: cita id; Type: DEFAULT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.cita ALTER COLUMN id SET DEFAULT nextval('hospitalario.cita_id_seq'::regclass);


--
-- Name: consultamedica id; Type: DEFAULT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.consultamedica ALTER COLUMN id SET DEFAULT nextval('hospitalario.consultamedica_id_seq'::regclass);


--
-- Name: consultorio idconsultorio; Type: DEFAULT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.consultorio ALTER COLUMN idconsultorio SET DEFAULT nextval('hospitalario.consultorio_idconsultorio_seq'::regclass);


--
-- Name: saladeespera idsala; Type: DEFAULT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.saladeespera ALTER COLUMN idsala SET DEFAULT nextval('hospitalario.saladeespera_idsala_seq'::regclass);


--
-- Name: visita id; Type: DEFAULT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.visita ALTER COLUMN id SET DEFAULT nextval('hospitalario.visita_id_seq'::regclass);


--
-- Name: bank id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.bank ALTER COLUMN id SET DEFAULT nextval('public.bank_id_seq'::regclass);


--
-- Name: function id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.function ALTER COLUMN id SET DEFAULT nextval('public.function_id_seq'::regclass);


--
-- Name: personextension id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.personextension ALTER COLUMN id SET DEFAULT nextval('public.personextension_id_seq'::regclass);


--
-- Name: privilege id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.privilege ALTER COLUMN id SET DEFAULT nextval('public.privilege_id_seq'::regclass);


--
-- Name: rol id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rol ALTER COLUMN id SET DEFAULT nextval('public.rol_id_seq'::regclass);


--
-- Name: securityelement id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.securityelement ALTER COLUMN id SET DEFAULT nextval('public.securityelement_id_seq'::regclass);


--
-- Data for Name: area; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.area (id, nombre) FROM stdin;
\.
COPY hospitalario.area (id, nombre) FROM '$$PATH$$/4157.dat';

--
-- Data for Name: beneficiario; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.beneficiario (cedula, vinculo) FROM stdin;
\.
COPY hospitalario.beneficiario (cedula, vinculo) FROM '$$PATH$$/4159.dat';

--
-- Data for Name: cita; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.cita (id, cedula, codigoespecialidad, fechadia, fechacita, fechaentradacola, fechapasaconsulta, fechafinconsulta, idbiostar) FROM stdin;
\.
COPY hospitalario.cita (id, cedula, codigoespecialidad, fechadia, fechacita, fechaentradacola, fechapasaconsulta, fechafinconsulta, idbiostar) FROM '$$PATH$$/4160.dat';

--
-- Data for Name: consultamedica; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.consultamedica (id, cedula, cedulamedico, sintomas, diagnostico, tratamiento, examenes, fecha, idcita) FROM stdin;
\.
COPY hospitalario.consultamedica (id, cedula, cedulamedico, sintomas, diagnostico, tratamiento, examenes, fecha, idcita) FROM '$$PATH$$/4162.dat';

--
-- Data for Name: consultorio; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.consultorio (idconsultorio, idsala, nombre) FROM stdin;
\.
COPY hospitalario.consultorio (idconsultorio, idsala, nombre) FROM '$$PATH$$/4164.dat';

--
-- Data for Name: empresa; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.empresa (codigo, nombre) FROM stdin;
\.
COPY hospitalario.empresa (codigo, nombre) FROM '$$PATH$$/4166.dat';

--
-- Data for Name: especialidad; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.especialidad (codigoespecialidad, nombre, autogestionada, diasdeatencion, cantidadmaximapacientes) FROM stdin;
\.
COPY hospitalario.especialidad (codigoespecialidad, nombre, autogestionada, diasdeatencion, cantidadmaximapacientes) FROM '$$PATH$$/4167.dat';

--
-- Data for Name: especialidadsalaspera; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.especialidadsalaspera (codi_espe, idsala) FROM stdin;
\.
COPY hospitalario.especialidadsalaspera (codi_espe, idsala) FROM '$$PATH$$/4168.dat';

--
-- Data for Name: estado; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.estado (codigo, nombre) FROM stdin;
\.
COPY hospitalario.estado (codigo, nombre) FROM '$$PATH$$/4169.dat';

--
-- Data for Name: estatustrabajador; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.estatustrabajador (codigo, nombre) FROM stdin;
\.
COPY hospitalario.estatustrabajador (codigo, nombre) FROM '$$PATH$$/4170.dat';

--
-- Data for Name: historiamedica; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.historiamedica (cedula, gruposanguineo, discapacidad, fecha) FROM stdin;
\.
COPY hospitalario.historiamedica (cedula, gruposanguineo, discapacidad, fecha) FROM '$$PATH$$/4171.dat';

--
-- Data for Name: medico; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.medico (cedulamedico, codigoespecialidad, codigoconsultorio) FROM stdin;
\.
COPY hospitalario.medico (cedulamedico, codigoespecialidad, codigoconsultorio) FROM '$$PATH$$/4172.dat';

--
-- Data for Name: municipio; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.municipio (codigo, nombre, codigopadre) FROM stdin;
\.
COPY hospitalario.municipio (codigo, nombre, codigopadre) FROM '$$PATH$$/4173.dat';

--
-- Data for Name: parroquia; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.parroquia (codigo, nombre, codigopadre) FROM stdin;
\.
COPY hospitalario.parroquia (codigo, nombre, codigopadre) FROM '$$PATH$$/4174.dat';

--
-- Data for Name: patologia; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.patologia (codigopatologia, nombre) FROM stdin;
\.
COPY hospitalario.patologia (codigopatologia, nombre) FROM '$$PATH$$/4175.dat';

--
-- Data for Name: patologiahistoriamedica; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.patologiahistoriamedica (cedula, codigopatologia) FROM stdin;
\.
COPY hospitalario.patologiahistoriamedica (cedula, codigopatologia) FROM '$$PATH$$/4176.dat';

--
-- Data for Name: persona; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.persona (cedula, nombres, apellidos, nacionalidad, fechanacimiento, sexo, nivel, profesion, telefonocelular, telefonoresidencia, correo, codigoestado, codigomunicipio, parroquia, sector, avenidacalle, edifcasa) FROM stdin;
\.
COPY hospitalario.persona (cedula, nombres, apellidos, nacionalidad, fechanacimiento, sexo, nivel, profesion, telefonocelular, telefonoresidencia, correo, codigoestado, codigomunicipio, parroquia, sector, avenidacalle, edifcasa) FROM '$$PATH$$/4177.dat';

--
-- Data for Name: saladeespera; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.saladeespera (idsala, nombre) FROM stdin;
\.
COPY hospitalario.saladeespera (idsala, nombre) FROM '$$PATH$$/4178.dat';

--
-- Data for Name: tipocargo; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.tipocargo (codigo, nombre) FROM stdin;
\.
COPY hospitalario.tipocargo (codigo, nombre) FROM '$$PATH$$/4180.dat';

--
-- Data for Name: tiponomina; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.tiponomina (codigo, nombre) FROM stdin;
\.
COPY hospitalario.tiponomina (codigo, nombre) FROM '$$PATH$$/4181.dat';

--
-- Data for Name: tipotrabajador; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.tipotrabajador (codigo, nombre) FROM stdin;
\.
COPY hospitalario.tipotrabajador (codigo, nombre) FROM '$$PATH$$/4182.dat';

--
-- Data for Name: trabajador; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.trabajador (cedula, personal, tiponomina, ubicacionlaboral, cargo, codigoempresa, jornada, ingreso, situacion, condicion, camisa, pantalon, calzado, ficha, observaciones, fechaactualizacion, idusuarioactualizacion, suspendido) FROM stdin;
\.
COPY hospitalario.trabajador (cedula, personal, tiponomina, ubicacionlaboral, cargo, codigoempresa, jornada, ingreso, situacion, condicion, camisa, pantalon, calzado, ficha, observaciones, fechaactualizacion, idusuarioactualizacion, suspendido) FROM '$$PATH$$/4183.dat';

--
-- Data for Name: ubicacionlaboral; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.ubicacionlaboral (codigo, nombre) FROM stdin;
\.
COPY hospitalario.ubicacionlaboral (codigo, nombre) FROM '$$PATH$$/4184.dat';

--
-- Data for Name: visita; Type: TABLE DATA; Schema: hospitalario; Owner: doadmin
--

COPY hospitalario.visita (cedula, idarea, nombre, apellidos, telefonocelular, telefonofijo, correo, responsable, id) FROM stdin;
\.
COPY hospitalario.visita (cedula, idarea, nombre, apellidos, telefonocelular, telefonofijo, correo, responsable, id) FROM '$$PATH$$/4185.dat';

--
-- Data for Name: bank; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.bank (id, name, status) FROM stdin;
\.
COPY public.bank (id, name, status) FROM '$$PATH$$/4187.dat';

--
-- Data for Name: function; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.function (id, name, long_name, link, icon, is_container, parent_id, "order", status) FROM stdin;
\.
COPY public.function (id, name, long_name, link, icon, is_container, parent_id, "order", status) FROM '$$PATH$$/4189.dat';

--
-- Data for Name: function_rol; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.function_rol (rol_id, function_id) FROM stdin;
\.
COPY public.function_rol (rol_id, function_id) FROM '$$PATH$$/4191.dat';

--
-- Data for Name: personextension; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.personextension (id, type, id_number, first_name, last_name, fullname, birth_date, gender, address, phone_number, email, secondary_email, bank_id, account_number, status, cedula) FROM stdin;
\.
COPY public.personextension (id, type, id_number, first_name, last_name, fullname, birth_date, gender, address, phone_number, email, secondary_email, bank_id, account_number, status, cedula) FROM '$$PATH$$/4192.dat';

--
-- Data for Name: privilege; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.privilege (id, short_name, name) FROM stdin;
\.
COPY public.privilege (id, short_name, name) FROM '$$PATH$$/4194.dat';

--
-- Data for Name: rol; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.rol (id, name) FROM stdin;
\.
COPY public.rol (id, name) FROM '$$PATH$$/4196.dat';

--
-- Data for Name: rol_privilege; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.rol_privilege (rol_id, privilege_id) FROM stdin;
\.
COPY public.rol_privilege (rol_id, privilege_id) FROM '$$PATH$$/4198.dat';

--
-- Data for Name: securityelement; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.securityelement (id, name, password_hash, status, discriminator) FROM stdin;
\.
COPY public.securityelement (id, name, password_hash, status, discriminator) FROM '$$PATH$$/4199.dat';

--
-- Data for Name: securityelement_rol; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.securityelement_rol (securityelement_id, rol_id) FROM stdin;
\.
COPY public.securityelement_rol (securityelement_id, rol_id) FROM '$$PATH$$/4201.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public."user" (id, person_extension_id, operation_key, register_mode, register_date, type) FROM stdin;
\.
COPY public."user" (id, person_extension_id, operation_key, register_mode, register_date, type) FROM '$$PATH$$/4202.dat';

--
-- Name: area_id_seq; Type: SEQUENCE SET; Schema: hospitalario; Owner: doadmin
--

SELECT pg_catalog.setval('hospitalario.area_id_seq', 1, false);


--
-- Name: cita_id_seq; Type: SEQUENCE SET; Schema: hospitalario; Owner: doadmin
--

SELECT pg_catalog.setval('hospitalario.cita_id_seq', 1, false);


--
-- Name: consultamedica_id_seq; Type: SEQUENCE SET; Schema: hospitalario; Owner: doadmin
--

SELECT pg_catalog.setval('hospitalario.consultamedica_id_seq', 1, false);


--
-- Name: consultorio_idconsultorio_seq; Type: SEQUENCE SET; Schema: hospitalario; Owner: doadmin
--

SELECT pg_catalog.setval('hospitalario.consultorio_idconsultorio_seq', 1, false);


--
-- Name: saladeespera_idsala_seq; Type: SEQUENCE SET; Schema: hospitalario; Owner: doadmin
--

SELECT pg_catalog.setval('hospitalario.saladeespera_idsala_seq', 1, false);


--
-- Name: visita_id_seq; Type: SEQUENCE SET; Schema: hospitalario; Owner: doadmin
--

SELECT pg_catalog.setval('hospitalario.visita_id_seq', 1, false);


--
-- Name: bank_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.bank_id_seq', 500, true);


--
-- Name: function_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.function_id_seq', 500, true);


--
-- Name: personextension_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.personextension_id_seq', 550, true);


--
-- Name: privilege_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.privilege_id_seq', 500, true);


--
-- Name: rol_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.rol_id_seq', 500, true);


--
-- Name: securityelement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.securityelement_id_seq', 551, true);


--
-- Name: area pk_area; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.area
    ADD CONSTRAINT pk_area PRIMARY KEY (id);


--
-- Name: beneficiario pk_beneficiario; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.beneficiario
    ADD CONSTRAINT pk_beneficiario PRIMARY KEY (cedula);


--
-- Name: cita pk_cita; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.cita
    ADD CONSTRAINT pk_cita PRIMARY KEY (id);


--
-- Name: consultamedica pk_consultamedica; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.consultamedica
    ADD CONSTRAINT pk_consultamedica PRIMARY KEY (id);


--
-- Name: consultorio pk_consultorio; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.consultorio
    ADD CONSTRAINT pk_consultorio PRIMARY KEY (idconsultorio);


--
-- Name: empresa pk_empresa; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.empresa
    ADD CONSTRAINT pk_empresa PRIMARY KEY (codigo);


--
-- Name: especialidad pk_especialidad; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.especialidad
    ADD CONSTRAINT pk_especialidad PRIMARY KEY (codigoespecialidad);


--
-- Name: especialidadsalaspera pk_especialidadsalaspera; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.especialidadsalaspera
    ADD CONSTRAINT pk_especialidadsalaspera PRIMARY KEY (codi_espe, idsala);


--
-- Name: estado pk_estado; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.estado
    ADD CONSTRAINT pk_estado PRIMARY KEY (codigo);


--
-- Name: estatustrabajador pk_estatustrabajador; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.estatustrabajador
    ADD CONSTRAINT pk_estatustrabajador PRIMARY KEY (codigo);


--
-- Name: historiamedica pk_historiamedica; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.historiamedica
    ADD CONSTRAINT pk_historiamedica PRIMARY KEY (cedula);


--
-- Name: medico pk_medico; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.medico
    ADD CONSTRAINT pk_medico PRIMARY KEY (cedulamedico);


--
-- Name: municipio pk_municipio; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.municipio
    ADD CONSTRAINT pk_municipio PRIMARY KEY (codigo);


--
-- Name: parroquia pk_parroquia; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.parroquia
    ADD CONSTRAINT pk_parroquia PRIMARY KEY (codigo);


--
-- Name: patologia pk_patologia; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.patologia
    ADD CONSTRAINT pk_patologia PRIMARY KEY (codigopatologia);


--
-- Name: patologiahistoriamedica pk_patologiahistoriamedica; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.patologiahistoriamedica
    ADD CONSTRAINT pk_patologiahistoriamedica PRIMARY KEY (cedula, codigopatologia);


--
-- Name: persona pk_persona; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.persona
    ADD CONSTRAINT pk_persona PRIMARY KEY (cedula);


--
-- Name: saladeespera pk_saladeespera; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.saladeespera
    ADD CONSTRAINT pk_saladeespera PRIMARY KEY (idsala);


--
-- Name: tipocargo pk_tipocargo; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.tipocargo
    ADD CONSTRAINT pk_tipocargo PRIMARY KEY (codigo);


--
-- Name: tiponomina pk_tiponomina; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.tiponomina
    ADD CONSTRAINT pk_tiponomina PRIMARY KEY (codigo);


--
-- Name: tipotrabajador pk_tipotrabajador; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.tipotrabajador
    ADD CONSTRAINT pk_tipotrabajador PRIMARY KEY (codigo);


--
-- Name: trabajador pk_trabajador; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.trabajador
    ADD CONSTRAINT pk_trabajador PRIMARY KEY (cedula);


--
-- Name: ubicacionlaboral pk_ubicacionlaboral; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.ubicacionlaboral
    ADD CONSTRAINT pk_ubicacionlaboral PRIMARY KEY (codigo);


--
-- Name: visita visita_pk; Type: CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.visita
    ADD CONSTRAINT visita_pk PRIMARY KEY (id);


--
-- Name: bank bank_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.bank
    ADD CONSTRAINT bank_pkey PRIMARY KEY (id);


--
-- Name: function function_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_pkey PRIMARY KEY (id);


--
-- Name: personextension personextension_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.personextension
    ADD CONSTRAINT personextension_pkey PRIMARY KEY (id);


--
-- Name: privilege privilege_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.privilege
    ADD CONSTRAINT privilege_pkey PRIMARY KEY (id);


--
-- Name: privilege privilege_short_name_key; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.privilege
    ADD CONSTRAINT privilege_short_name_key UNIQUE (short_name);


--
-- Name: rol rol_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT rol_pkey PRIMARY KEY (id);


--
-- Name: securityelement securityelement_name_key; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.securityelement
    ADD CONSTRAINT securityelement_name_key UNIQUE (name);


--
-- Name: securityelement securityelement_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.securityelement
    ADD CONSTRAINT securityelement_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: idx_especialidad1; Type: INDEX; Schema: hospitalario; Owner: doadmin
--

CREATE UNIQUE INDEX idx_especialidad1 ON hospitalario.especialidad USING btree (nombre);


--
-- Name: idx_patologia1; Type: INDEX; Schema: hospitalario; Owner: doadmin
--

CREATE UNIQUE INDEX idx_patologia1 ON hospitalario.patologia USING btree (nombre);


--
-- Name: beneficiario fk_benefici_reference_persona; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.beneficiario
    ADD CONSTRAINT fk_benefici_reference_persona FOREIGN KEY (cedula) REFERENCES hospitalario.persona(cedula) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: beneficiario fk_benefici_reference_trabajad; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.beneficiario
    ADD CONSTRAINT fk_benefici_reference_trabajad FOREIGN KEY (cedula) REFERENCES hospitalario.trabajador(cedula) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: cita fk_cita_reference_especial; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.cita
    ADD CONSTRAINT fk_cita_reference_especial FOREIGN KEY (codigoespecialidad) REFERENCES hospitalario.especialidad(codigoespecialidad) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: cita fk_cita_reference_persona; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.cita
    ADD CONSTRAINT fk_cita_reference_persona FOREIGN KEY (cedula) REFERENCES hospitalario.persona(cedula) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultamedica fk_consulta_reference_cita; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.consultamedica
    ADD CONSTRAINT fk_consulta_reference_cita FOREIGN KEY (idcita) REFERENCES hospitalario.cita(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultamedica fk_consulta_reference_historia; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.consultamedica
    ADD CONSTRAINT fk_consulta_reference_historia FOREIGN KEY (cedula) REFERENCES hospitalario.historiamedica(cedula) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultamedica fk_consulta_reference_medico; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.consultamedica
    ADD CONSTRAINT fk_consulta_reference_medico FOREIGN KEY (cedulamedico) REFERENCES hospitalario.medico(cedulamedico) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultamedica fk_consulta_reference_persona; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.consultamedica
    ADD CONSTRAINT fk_consulta_reference_persona FOREIGN KEY (cedula) REFERENCES hospitalario.persona(cedula) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultorio fk_consulto_reference_saladees; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.consultorio
    ADD CONSTRAINT fk_consulto_reference_saladees FOREIGN KEY (idsala) REFERENCES hospitalario.saladeespera(idsala) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: especialidadsalaspera fk_especial_reference_especial; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.especialidadsalaspera
    ADD CONSTRAINT fk_especial_reference_especial FOREIGN KEY (codi_espe) REFERENCES hospitalario.especialidad(codigoespecialidad) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: especialidadsalaspera fk_especial_reference_saladees; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.especialidadsalaspera
    ADD CONSTRAINT fk_especial_reference_saladees FOREIGN KEY (idsala) REFERENCES hospitalario.saladeespera(idsala) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: historiamedica fk_historia_reference_persona; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.historiamedica
    ADD CONSTRAINT fk_historia_reference_persona FOREIGN KEY (cedula) REFERENCES hospitalario.persona(cedula) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: medico fk_medico_reference_consulto; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.medico
    ADD CONSTRAINT fk_medico_reference_consulto FOREIGN KEY (codigoconsultorio) REFERENCES hospitalario.consultorio(idconsultorio) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: medico fk_medico_reference_especial; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.medico
    ADD CONSTRAINT fk_medico_reference_especial FOREIGN KEY (codigoespecialidad) REFERENCES hospitalario.especialidad(codigoespecialidad) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: medico fk_medico_reference_persona; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.medico
    ADD CONSTRAINT fk_medico_reference_persona FOREIGN KEY (cedulamedico) REFERENCES hospitalario.persona(cedula) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: municipio fk_municipi_reference_estado; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.municipio
    ADD CONSTRAINT fk_municipi_reference_estado FOREIGN KEY (codigopadre) REFERENCES hospitalario.estado(codigo);


--
-- Name: patologiahistoriamedica fk_patologi_reference_historia; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.patologiahistoriamedica
    ADD CONSTRAINT fk_patologi_reference_historia FOREIGN KEY (cedula) REFERENCES hospitalario.historiamedica(cedula) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: patologiahistoriamedica fk_patologi_reference_patologi; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.patologiahistoriamedica
    ADD CONSTRAINT fk_patologi_reference_patologi FOREIGN KEY (codigopatologia) REFERENCES hospitalario.patologia(codigopatologia) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: trabajador fk_trabajad_reference_empresa; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.trabajador
    ADD CONSTRAINT fk_trabajad_reference_empresa FOREIGN KEY (codigoempresa) REFERENCES hospitalario.empresa(codigo) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: trabajador fk_trabajad_reference_persona; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.trabajador
    ADD CONSTRAINT fk_trabajad_reference_persona FOREIGN KEY (cedula) REFERENCES hospitalario.persona(cedula) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: trabajador fk_trabajad_reference_user; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.trabajador
    ADD CONSTRAINT fk_trabajad_reference_user FOREIGN KEY (idusuarioactualizacion) REFERENCES public."user"(id);


--
-- Name: visita fk_visitant_reference_area; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.visita
    ADD CONSTRAINT fk_visitant_reference_area FOREIGN KEY (idarea) REFERENCES hospitalario.area(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: parroquia parroquia_fk; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.parroquia
    ADD CONSTRAINT parroquia_fk FOREIGN KEY (codigopadre) REFERENCES hospitalario.municipio(codigo);


--
-- Name: persona persona_fk; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.persona
    ADD CONSTRAINT persona_fk FOREIGN KEY (codigoestado) REFERENCES hospitalario.estado(codigo);


--
-- Name: persona persona_fk_1; Type: FK CONSTRAINT; Schema: hospitalario; Owner: doadmin
--

ALTER TABLE ONLY hospitalario.persona
    ADD CONSTRAINT persona_fk_1 FOREIGN KEY (codigomunicipio) REFERENCES hospitalario.municipio(codigo);


--
-- Name: function function_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.function(id);


--
-- Name: function_rol function_rol_function_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.function_rol
    ADD CONSTRAINT function_rol_function_id_fkey FOREIGN KEY (function_id) REFERENCES public.function(id);


--
-- Name: function_rol function_rol_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.function_rol
    ADD CONSTRAINT function_rol_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.rol(id);


--
-- Name: personextension personextension_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.personextension
    ADD CONSTRAINT personextension_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.bank(id);


--
-- Name: personextension personextension_fk; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.personextension
    ADD CONSTRAINT personextension_fk FOREIGN KEY (cedula) REFERENCES hospitalario.persona(cedula);


--
-- Name: rol_privilege rol_privilege_privilege_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rol_privilege
    ADD CONSTRAINT rol_privilege_privilege_id_fkey FOREIGN KEY (privilege_id) REFERENCES public.privilege(id);


--
-- Name: rol_privilege rol_privilege_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rol_privilege
    ADD CONSTRAINT rol_privilege_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.rol(id);


--
-- Name: securityelement_rol securityelement_rol_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.securityelement_rol
    ADD CONSTRAINT securityelement_rol_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.rol(id);


--
-- Name: securityelement_rol securityelement_rol_securityelement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.securityelement_rol
    ADD CONSTRAINT securityelement_rol_securityelement_id_fkey FOREIGN KEY (securityelement_id) REFERENCES public.securityelement(id);


--
-- Name: user user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_id_fkey FOREIGN KEY (id) REFERENCES public.securityelement(id);


--
-- Name: user user_person_extension_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_person_extension_id_fkey FOREIGN KEY (person_extension_id) REFERENCES public.personextension(id);


--
-- PostgreSQL database dump complete
--

